document.addEventListener('DOMContentLoaded', function() {
  const searchInput = document.getElementById('searchInput');
  const hint = document.getElementById('hint');
  
  // 搜索引擎配置
  const searchEngines = {
    baidu: {
      name: 'Baidu',
      url: 'https://www.baidu.com/s?wd=',
      hint: '输入搜索内容后回车以使用百度搜索'
    },
    // 可以添加更多搜索引擎
    google: {
      name: 'Google',
      url: 'https://www.google.com/search?q=',
      hint: '输入搜索内容后回车以使用Google搜索'
    },
    bing: {
      name: 'Bing',
      url: 'https://www.cn.bing.com/search?q=',
      hint: '输入搜索内容后回车以使用Bing搜索'
    }
  };

  let currentEngine = null;
  let isWaitingForQuery = false;

  searchInput.addEventListener('keydown', function(e) {
    if (e.key === 'Tab' && !isWaitingForQuery) {
      e.preventDefault();
      const command = searchInput.value.toLowerCase().trim();
      
      if (searchEngines[command]) {
        currentEngine = searchEngines[command];
        isWaitingForQuery = true;
        searchInput.value = '';
        hint.textContent = currentEngine.hint;
        hint.style.display = 'block';
      }
    } else if (e.key === 'Enter' && isWaitingForQuery && currentEngine) {
      e.preventDefault();
      const query = searchInput.value.trim();
      if (query) {
        const searchUrl = currentEngine.url + encodeURIComponent(query);
        chrome.tabs.create({ url: searchUrl });
        window.close();
      }
    } else if (e.key === 'Escape') {
      if (isWaitingForQuery) {
        isWaitingForQuery = false;
        currentEngine = null;
        hint.style.display = 'none';
        searchInput.value = '';
      } else {
        window.close();
      }
    }
  });

  // 输入时更新提示
  searchInput.addEventListener('input', function() {
    if (!isWaitingForQuery) {
      const command = searchInput.value.toLowerCase().trim();
      if (searchEngines[command]) {
        hint.textContent = '按 Tab 键继续';
        hint.style.display = 'block';
      } else {
        hint.style.display = 'none';
      }
    }
  });
}); 